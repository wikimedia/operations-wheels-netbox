from debug_toolbar.panels.sql.panel import SQLPanel  # noqa
