SUPPORTED_DRIVERS = [
    "base",
    "eos",
    "ios",
    "iosxr",
    "junos",
    "nxos",
    "nxos_ssh",
]
