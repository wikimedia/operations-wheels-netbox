from __future__ import unicode_literals
from netmiko.linux.linux_ssh import LinuxSSH


class OvsLinuxSSH(LinuxSSH):
    pass
