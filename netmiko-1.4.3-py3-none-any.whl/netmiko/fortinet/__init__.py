from __future__ import unicode_literals
from netmiko.fortinet.fortinet_ssh import FortinetSSH

__all__ = ['FortinetSSH']
