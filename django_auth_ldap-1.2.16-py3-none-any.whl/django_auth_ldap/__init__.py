version = (1, 2, 16)
version_string = '.'.join(map(str, version))
