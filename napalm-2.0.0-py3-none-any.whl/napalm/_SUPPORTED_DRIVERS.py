SUPPORTED_DRIVERS = [
    "eos",
    "ios",
    "iosxr",
    "junos",
    "nxos",
    "nxos_ssh",
]
