from jnpr.junos.cfg.resource import Resource
