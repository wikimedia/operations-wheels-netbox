from pyFG.fortios import FortiOS
from pyFG.forticonfig import FortiConfig

__all__ = ['FortiOS', 'FortiConfig']
